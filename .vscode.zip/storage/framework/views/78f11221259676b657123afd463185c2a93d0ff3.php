<?php $__env->startSection('adminHome'); ?>

  <section>
    <div id="wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <ul>
                <li>
                    <i class="fas fa-users"></i> <a class="ad-active" href="<?php echo e(route('admin.home')); ?>">Profile</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.createCourse')); ?>">Create Course</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.viewCourse')); ?>">View Course</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.approveStudent')); ?>">Approve Student</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.approveTeacher')); ?>">Approve Teacher</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.viewStudent')); ?>">Student Info</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.viewTeacher')); ?>">Teacher Info</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.notesUpload')); ?>">Notes Upload</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.noticeUpload')); ?>">Notice Upload</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.marksCreate')); ?>">Create Marks</a>
                </li>

                <li>
                    <i class="fas fa-hands-helping"></i> <a href="<?php echo e(route('admin.entrySalary')); ?>">Entry Salary</a>
                </li>

                <li>
                    <i class="fas fa-hands-helping"></i> <a href="<?php echo e(route('admin.viewSalary')); ?>">View Salary</a>
                </li>
                <li>
                    <i class="fas fa-hands-helping"></i> <a href="<?php echo e(route('admin.alertParent')); ?>">Alert Parents</a>
                </li>
                <li>
                    <i class="fas fa-hands-helping"></i> <a href="<?php echo e(route('admin.report')); ?>">Report</a>
                </li>
            </ul>
        </div>

        <div id="content-wrapper">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <h1 class="mt-5">Admin Info </h1>
                    </div>
                    <div class="col-lg-8 my-5 p-5" style="border: 3px solid #f58776;">
                        <h3>Name: <span><?php echo e($data->uname); ?></span></h3>
                        <h3>Email: <?php echo e($data->uemail); ?></h3>
                        <a href="<?php echo e(route('admin.profileEdit',['id'=>session('regid')])); ?>" class="btn btn-warning mt-3">Edit</a>
                    </div>
                <div>
            </div>
            </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vanila\resources\views/admin/adminHome.blade.php ENDPATH**/ ?>