<h3>You have a message from Vanila Academy Coaching Center</h3>
<div>
    <?php echo e($bodyMessage); ?>

</div>
<p>Sent via <?php echo e($email); ?></p>
<?php /**PATH C:\xampp\htdocs\vanila\resources\views/admin/email.blade.php ENDPATH**/ ?>