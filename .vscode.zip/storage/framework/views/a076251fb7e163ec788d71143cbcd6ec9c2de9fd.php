<?php $__env->startSection('adminReport'); ?>

<section>
    <div id="wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <ul>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.home')); ?>">Profile</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.createCourse')); ?>">Create Course</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.viewCourse')); ?>">View Course</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.approveStudent')); ?>">Approve Student</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.approveTeacher')); ?>">Approve Teacher</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.viewStudent')); ?>">Student Info</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.viewTeacher')); ?>">Teacher Info</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.notesUpload')); ?>">Notes Upload</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.noticeUpload')); ?>">Notice Upload</a>
                </li>
                <li>
                    <i class="fas fa-users"></i> <a href="<?php echo e(route('admin.marksCreate')); ?>">Create Marks</a>
                </li>

                <li>
                    <i class="fas fa-hands-helping"></i> <a href="<?php echo e(route('admin.entrySalary')); ?>">Entry Salary</a>
                </li>

                <li>
                    <i class="fas fa-hands-helping"></i> <a href="<?php echo e(route('admin.viewSalary')); ?>">View Salary</a>
                </li>
                <li>
                    <i class="fas fa-hands-helping"></i> <a href="<?php echo e(route('admin.alertParent')); ?>">Alert Parents</a>
                </li>
                <li>
                    <i class="fas fa-hands-helping"></i> <a class="ad-active" href="<?php echo e(route('admin.report')); ?>">Report</a>
                </li>
            </ul>
        </div>

        <div id="content-wrapper">
            <div class="container-fluid">
                <div class="row justify-content-center text-center">
                    <div class="col-lg-8 mb-4 mr-auto">
                        <h1> View Report</h1>
                    </div>
                    <div class="col-lg-8 mb-4 ml-auto">
                        <form action="<?php echo e(route('admin.report')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-success">Download Excel</button>
                        </form>
                    </div>
                    <div class="col-lg-10">
                        <table class="table table-hover table-primary">
                            <thead class="table-danger">
                            <tr>
                                <th>STUDENT ID</th>
                                <th>NAME</th>
                                <th>FEES</th>
                                <th>PAID</th>
                            </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($value->id); ?></th>
                                    <th><?php echo e($value->name); ?></th>
                                    <th><?php echo e($value->fees); ?></th>
                                    <th><?php echo e($value->paid); ?></th>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vanila\resources\views/admin/adminReport.blade.php ENDPATH**/ ?>