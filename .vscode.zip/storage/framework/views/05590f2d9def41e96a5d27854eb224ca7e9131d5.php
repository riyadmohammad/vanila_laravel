<?php $__env->startSection('login'); ?>
<section class="nav-section">
    <nav class="nav-design">
        <div class="logo">
            <h2>Vanila</h2>
        </div>

        <ul>
            <li>
                <a href="<?php echo e(route('landingpage')); ?>"> Home </a>
            </li>
            <li>
                <a href="#about-us"> About Us</a>
            </li>
            <li>
                <a href="courses.html"> Courses</a>
            </li>
            <li>
                <a href="notice.html"> Notice </a>
            </li>
            <li>
                <a href="contact.html"> Contact </a>
            </li>
            <li>
                <a href="<?php echo e(route('login')); ?>" class="active"> Sign In </a>
            </li>
            <li>
                <a href="<?php echo e(route('student.reg')); ?>" class="n-btn"> Register </a>
            </li>
        </ul>
    </nav>
</section>

<section class="form-section">
    <div class="container">
        <div class="row justify-content-center text-center">
            <div class="col-lg-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span style="background-color: #0043ff5e; padding:6px; font-size: 18px;  font-weight: 700; display:block;"
                ><?php echo e($err); ?> </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <span style="font-size: 18px;  font-weight: 700; display:block;"
                   ><?php echo e(session('msg')); ?> </span>

                   <br>
                <form class="login-form" action="<?php echo e(route('login')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                      <label for="uemail">Email address</label>
                      <input type="text" class="form-control" name="uemail"      placeholder="enter email" value="<?php echo e(old('uemail')); ?>">
                    </div>
                    <div class="form-group">
                      <label for="pass">Password</label>
                      <input type="password" class="form-control" name="upassword" placeholder="enter password" value="<?php echo e(old('upassword')); ?>">
                    </div>

                    <button type="submit"  class="btn btn-dark" >LogIn</button>
                </form>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vanila\resources\views/Login/login.blade.php ENDPATH**/ ?>