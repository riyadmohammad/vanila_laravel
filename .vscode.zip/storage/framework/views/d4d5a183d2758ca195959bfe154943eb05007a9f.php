<?php $__env->startSection('studentReg'); ?>

    <section class="nav-section">
        <nav class="nav-design">
            <div class="logo">
                <h2>Vanila</h2>
            </div>

            <ul>
                <li>
                    <a href="<?php echo e(route('landingpage')); ?>"> Home </a>
                </li>
                <li>
                    <a href="#about-us"> About Us</a>
                </li>
                <li>
                    <a href="courses.html"> Courses</a>
                </li>
                <li>
                    <a href="notice.html"> Notice </a>
                </li>
                <li>
                    <a href="contact.html"> Contact </a>
                </li>
                <li>
                    <a href="<?php echo e(route('login')); ?>"> Sign In </a>
                </li>
                <li>
                    <a href="<?php echo e(route('student.reg')); ?>" class="n-btn"> Register </a>
                </li>
            </ul>
        </nav>
    </section>

    <section class="my-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-right">
                    <a href="<?php echo e(route('teacher.reg')); ?>" class="btn btn-primary">Teacher Registration</a>
                </div>

                <div class="col-lg-8 my-2">
                    <h2 class="mb-2">Student Registration</h2>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span style="background-color: #0043ff5e; padding:6px; font-size: 18px;  font-weight: 700; display:block;"
                    ><?php echo e($err); ?> </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="col-lg-8">
                <form action="<?php echo e(route('student.reg')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="fullname">Full Name of Student:</label>
                        <input type="text" class="form-control" id="fullname" placeholder="Enter Name"
                        name="name" value="<?php echo e(old('name')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="SchoolCollege">Name of School/college:</label>
                        <input type="text" class="form-control" id="SchoolCollege" placeholder="Enter school/college"
                        name="institution" value="<?php echo e(old('institution')); ?>">
                    </div>


                    <div class="form-group">
                        <label for="exampleInputEmail1">Email</label>
                        <input type="text" class="form-control" id="email" placeholder="Enter Email Address"
                        name="email" value="<?php echo e(old('email')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input type="password" class="form-control" id="password" placeholder="Password"
                        name="password" value="<?php echo e(old('password')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="SPhoneNumber">Phone Number</label>
                        <input type="text" class="form-control" id="SPhoneNumber" placeholder="Phone Number"
                        name="phone" value="<?php echo e(old('phone')); ?>">
                    </div>

                    <div class="form-group">
                        <label  for="parents">Full Name of Parent:</label>
                        <input type="text" class="form-control" id="parents" placeholder="Enter Parents Name"
                        name="pname" value="<?php echo e(old('pname')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="exampleInputEmail1">Parent Email</label>
                        <input type="text" class="form-control" id="email" placeholder="Enter Email Address"
                        name="pemail" value="<?php echo e(old('pemail')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="PPhoneNumber">Parent Phone Number</label>
                        <input type="text" class="form-control" id="PPhoneNumber" placeholder="Phone Number"
                        name="pphone" value="<?php echo e(old('pphone')); ?>">
                    </div>

                    <button type="submit" class="btn btn-info">Submit</button>
            </form>
            </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vanila\resources\views/registration/studentReg.blade.php ENDPATH**/ ?>