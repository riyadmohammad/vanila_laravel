<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Coaching Management System</title>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/fontawesome/css/all.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/datatable.min.css')); ?>" />
    
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/responsive.css')); ?>" />
</head>

<body>
    <section class="nav-section">
        <header class="admin-panel">
            <nav class="nav-design">
                <div class="logo">
                    <h2>Vanila</h2>
                </div>
                <ul>
                    <li>
                        <h5><?php echo e(session('uname')); ?></h5>
                    </li>
                    <li>
                        <a href="" class="btn-primary"><i class="fas fa-bell"></i></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('logout')); ?>" class="n-btn"> Logout </a>
                    </li>
                </ul>
            </nav>
        </header>
    </section>

    <script src="<?php echo e(asset('public/assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/proper.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/bootstrap.js')); ?>"></script>
    
    <script src="http://cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>
    <?php echo $__env->yieldContent('adminHome'); ?>
    <?php echo $__env->yieldContent('adminProfileEdit'); ?>
    <?php echo $__env->yieldContent('adminCreateCourse'); ?>
    <?php echo $__env->yieldContent('adminViewCourse'); ?>
    <?php echo $__env->yieldContent('adminEditCourse'); ?>
    <?php echo $__env->yieldContent('adminApproveStudent'); ?>
    <?php echo $__env->yieldContent('adminApproveteacher'); ?>
    <?php echo $__env->yieldContent('adminViewStudent'); ?>
    <?php echo $__env->yieldContent('adminViewTeacher'); ?>
    <?php echo $__env->yieldContent('adminNoticeUpload'); ?>
    <?php echo $__env->yieldContent('adminMarksCreate'); ?>
    <?php echo $__env->yieldContent('adminEntrySalary'); ?>
    <?php echo $__env->yieldContent('adminViewSalary'); ?>
    <?php echo $__env->yieldContent('adminEditSalary'); ?>
    <?php echo $__env->yieldContent('adminNotesUpload'); ?>
    <?php echo $__env->yieldContent('adminAlertParent'); ?>
    <?php echo $__env->yieldContent('adminSendMail'); ?>
    <?php echo $__env->yieldContent('adminReport'); ?>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\vanila\resources\views/layouts/admin.blade.php ENDPATH**/ ?>