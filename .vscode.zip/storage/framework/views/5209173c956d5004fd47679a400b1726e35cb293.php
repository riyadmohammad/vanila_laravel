<?php $__env->startSection('studentReg'); ?>

    <section class="nav-section">
        <nav class="nav-design">
            <div class="logo">
                <h2>Vanila</h2>
            </div>

            <ul>
                <li>
                    <a href="<?php echo e(route('landingpage')); ?>"> Home </a>
                </li>
                <li>
                    <a href="#about-us"> About Us</a>
                </li>
                <li>
                    <a href="courses.html"> Courses</a>
                </li>
                <li>
                    <a href="notice.html"> Notice </a>
                </li>
                <li>
                    <a href="contact.html"> Contact </a>
                </li>
                <li>
                    <a href="<?php echo e(route('login')); ?>"> Sign In </a>
                </li>
                <li>
                    <a href="<?php echo e(route('student.reg')); ?>" class="n-btn"> Register </a>
                </li>
            </ul>
        </nav>
    </section>

    <section>
        <div class="container my-5">
            <div class="row justify-content-center ">
                <div class="col-lg-8 my-2">
                    <h2>Teacher Registration</h2>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span style="background-color: #0043ff5e; padding:6px; font-size: 18px;  font-weight: 700; display:block;"
                    ><?php echo e($err); ?> </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-lg-8">
                    <form action="<?php echo e(route('teacher.reg')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                                <label for="fullname">Full Name of Teacher:</label>
                                <input type="text" class="form-control" id="fullname" placeholder="Enter Name"
                                name="name" value="<?php echo e(old('name')); ?>">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Email</label>
                                <input type="text" class="form-control" id="email" placeholder="Enter Email Address"
                                name="email" value="<?php echo e(old('email')); ?>">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputPassword1">Password</label>
                                <input type="password" class="form-control" id="password" placeholder="Password"
                                name="password" value="<?php echo e(old('password')); ?>">
                            </div>

                            <div class="form-group">
                                <label for="TPhoneNumber">Phone Number</label>
                                <input type="text" class="form-control" id="TPhoneNumber" placeholder="Phone Number"
                                name="phone" value="<?php echo e(old('phone')); ?>">
                            </div>

                            <div class="form-group">
                                <label for="qualification_details">Qualification</label><br>
                                <textarea type="text" name="qualification" id="" cols="50" rows="10"></textarea>
                            </div>

                            <button type="submit" class="btn btn-info">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vanila\resources\views/registration/teacherReg.blade.php ENDPATH**/ ?>