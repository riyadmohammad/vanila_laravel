<h3>You have a message from Vanila Academy Coaching Center</h3>
<div>
    {{$bodyMessage}}
</div>
<p>Sent via {{$email}}</p>
